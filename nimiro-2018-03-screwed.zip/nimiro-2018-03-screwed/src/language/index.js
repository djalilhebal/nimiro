module.exports = {
	normalize: require('./language.normalizer'),
	americanizer: require('./language.americanizer'),
	tokenize: require('./language.tokenizer'),
	modeler: require('./language.modeler'),
}
