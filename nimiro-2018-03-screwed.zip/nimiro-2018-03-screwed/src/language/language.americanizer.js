function americanize(text) { // TODO
	return text;
}

module.exports = americanize;
