function makeitup(phons) {
	return phons.split('').join('a') + 'i';
}

module.exports = makeitup;
