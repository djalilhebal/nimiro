const markov = require('./generator.markov');
const makeitup = require('./generator.makeitup');
const cartesian = require('./generator.cartesian');

module.exports = { markov, cartesian, makeitup };
